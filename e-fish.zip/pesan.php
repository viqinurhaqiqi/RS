<!DOCTYPE html>
<html>
<head>
	<title>e-fish</title>
</head>
<link href="css/style.css" type="text/css" rel="stylesheet">
<body>

</body>
<div id="canvas">
	<div id="header">
	</div>

	<div id="menu">
		<ul>
			<li class="utama"><a href="index.php">Beranda</a></li>
			<li class="utama"><a href="bibitikan.php">Bibit Ikan</a></li>
			<li class="utama"><a href="pakanikan.php">Pakan Ikan</a></li>
			<li class="utama"><a href="pesan.php">Pesan</a>
			<ul>
				<li><a href="">Pesan Bibit Ikan</a></li>
				<li><a href="">Pesan Pakan Ikan</a></li>
			</ul>
			</li>
			<li class="utama"><a href="">Login</a>
			<ul>
				<li><a href="login.php">Administrator</a></li>
				<li><a href="loginuser.php">Pelanggan</a></li>
				<li><a href="">Daftar</a></li>
			</ul>
			</li>
		</ul>
	</div>

	<div id="isi">
		pemesanan ikan
	</div>

	<div id="footer">
		Copyright 2016 e-fish
	</div>
</div>
	
</html>